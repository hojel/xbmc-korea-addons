# -*- coding: utf-8 -*-
"""
    tvbayo
"""
import urllib
import urllib2
import re
import json
from bs4 import BeautifulSoup

ROOT_URL = "http://tvbayo.com"
http_hdrs = {
    "User-Agent":"Mozilla/5.0 (iPad; CPU OS 7_0 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A465 Safari/9537.53",
}

#########################################################################
def parseLivePage(url):
    req = urllib2.Request(url, headers=http_hdrs)
    doc = urllib2.urlopen(req).read()
    soup = BeautifulSoup(doc)
    result = []
    for item in soup.find('div', {'class':'main_live_wrap'}).find_all('li'):
        rurl = item.a['href']
        name = rurl.split('/')[-1]
        result.append( {'url':ROOT_URL+urllib.quote(rurl.encode('utf-8')), 'name':name, 'thumbnail':ROOT_URL+item.img['src']} )
    return result
    
def parseLivePage2(url):
    req = urllib2.Request(url, headers=http_hdrs)
    doc = urllib2.urlopen(req).read()
    result = []
    sect = re.compile('<div class="main_live_wrap">(.*?)</div>', re.S).search(doc).group(1)
    for rurl, thumb in re.compile('''<a href=['"](.*?)['"]> *<img src="(.*?)"''').findall(sect):
        name = rurl.split('/')[-1]
        result.append( {'url':ROOT_URL+urllib.quote(rurl), 'name':name, 'thumbnail':ROOT_URL+thumb} )
    return result
    
#########################################################################
def parseProgList(main_url):
    req = urllib2.Request(main_url, headers=http_hdrs)
    doc = urllib2.urlopen(req).read()
    soup = BeautifulSoup(doc)

    result = {'link':[]}
    for item in soup.find("div", {"class":"vod_list_wrap"}).findAll("a"):
        thumb = item.dl.dt.img['src']
        title = item.dl.dd.p.span.string.strip()
        url = item['href'].encode('utf-8')
        cate, pkw, year, pname = url.split('/')[1:]
        assert(pkw == 'program')
        result['link'].append({'title':title, 'category':cate, 'year':year, 'progname':pname, 'url':ROOT_URL+urllib.quote(url), 'thumbnail':thumb})

    # navigation
    cur = soup.find("ul", {"class":"pagination"}).find("li", {"class":"active"})
    p = cur.findPreviousSibling("li")
    if p.a and p.a.text.isdigit():
        url = ROOT_URL+p.a['href']
        result['prevpage'] = url
    p = cur.findNextSibling("li")
    if p.a and p.a.text.isdigit():
        url = ROOT_URL+p.a['href']
        result['nextpage'] = url
    return result

def parseProgList2(main_url):
    req = urllib2.Request(main_url, headers=http_hdrs)
    doc = urllib2.urlopen(req).read()

    result = {'link':[]}
    for url, thumb in re.compile('<a href="(.*?/program/.*?) *">.*?<img src="(.*?)"').findall(doc):
        title = url.split('/')[-1].strip()
        cate, pkw, year, pname = url.split('/')[1:]
        assert(pkw == 'program')
        result['link'].append({'title':title, 'category':cate, 'year':year, 'progname':pname, 'url':ROOT_URL+urllib.quote(url), 'thumbnail':thumb})

    # navigation
    navipt = re.compile('<ul class="pagination">(.*?)</ul>', re.S).search(doc).group(1)
    match = re.compile('<li><a href="([^"]*)">\d+</a></li>\s*<li class="active">').search(navipt)
    if match:
        url = ROOT_URL+match.group(1)
        result['prevpage'] = url
    match = re.compile('<li class="active">.*?<li><a href="([^"]*)">', re.S).search(navipt)
    if match:
        url = ROOT_URL+match.group(1)
        result['nextpage'] = url
    return result

#########################################################################
def parseProgPage(main_url):
    req = urllib2.Request(main_url, headers=http_hdrs)
    doc = urllib2.urlopen(req).read()
    soup = BeautifulSoup(doc)

    result = []
    for item in soup.find("div", {"class":"vf_program"}).findAll("li"):
        title = item.string
        url = ROOT_URL + urllib.quote(item.a['href'].encode('utf-8'))
        result.append({'title':title, 'url':url})
    return result

def parseProgPage2(main_url):
    req = urllib2.Request(main_url, headers=http_hdrs)
    doc = urllib2.urlopen(req).read()
    result = []
    sect = re.compile('<div class="vf_program">(.*)<div class="paginate">', re.S).search(doc).group(1)
    for rurl, title in re.compile('<a href="(.*?)">(.*?)</a>').findall(sect):
        url = ROOT_URL + urllib.quote(rurl)
        result.append({'title':title, 'url':url})
    return result

#########################################################################
def resolve_tvbao_url(url):
    req = urllib2.Request(url, headers=http_hdrs)
    doc = urllib2.urlopen(req).read()
    soup = BeautifulSoup(doc)
    return soup.find('div', {'class':'to_view'}).a['href']

def resolve_wooribs_url(url):
    #
    req = urllib2.Request(url, headers=http_hdrs)
    doc = urllib2.urlopen(req).read()
    match = re.compile('p2psr_embed\("(.*?)", *"(.*?)", *"(.*?)", *"(.*?)",').search(doc)
    if match is None:
        return None
    rurl = "%s%s.json?type=%s&callback=?" % match.group(3,4,2)
    stype = match.group(2)
    #
    req = urllib2.Request(rurl, headers=http_hdrs)
    doc = urllib2.urlopen(req).read()
    obj = json.loads(doc[2:-2])
    # m3u8
    info = obj[u'substreams'][0]
    if stype == "live":
        vurl = info[u'http_url'] + "/live.M3U8"
    else:   # vod
        stname = info[u'stream_name']
        if stname is None: stname = "video"
        vurl = "{}/{}.m3u8".format(info[u'http_url'], stname)
    return vurl

def extract_video_url(url):
    qurl = resolve_tvbao_url(url)
    return resolve_wooribs_url(qurl)

#########################################################################
if __name__ == "__main__":
    #print parseLivePage(ROOT_URL+urllib.quote("/live/종합편성"))
    #print extract_video_url(ROOT_URL+'/live/channel/KBS1')
    #print parseProgList(ROOT_URL+"/drama")
    #print parseProgList(ROOT_URL+"/ent?page=2")
    #print parseProgPage(ROOT_URL+urllib.quote("/ent/program/2016/삼시세끼 어촌편 3"))
    #print extract_video_url(ROOT_URL+urllib.quote("/ent/program/2016/삼시세끼 어촌편 3/11"))
    print extract_video_url(ROOT_URL+urllib.quote("/movie/program/2016/럭키"))
    #print parseLivePage2(ROOT_URL+urllib.quote("/live/종합편성"))
    #print parseProgList2(ROOT_URL+"/ent?page=2")
    #print parseProgPage2(ROOT_URL+urllib.quote("/ent/program/2016/삼시세끼 어촌편 3"))

# vim:sts=4:sw=4:et
