# -*- coding: utf-8 -*-
"""
    tvbayo.com
"""
from xbmcswift2 import Plugin
import urllib
import os
import re

plugin = Plugin()
_L = plugin.get_string

plugin_path = plugin.addon.getAddonInfo('path')
sys.path.append( os.path.join(plugin_path, 'resources', 'lib') )

import tvbayo as scraper

tPrevPage = u"[B]<%s[/B]" % _L(30100)
tNextPage = u"[B]%s>[/B]" % _L(30101)
imgPrevPage = os.path.join(plugin_path, 'resources', 'media', 'previous.png')
imgNextPage = os.path.join(plugin_path, 'resources', 'media', 'next.png')

@plugin.route('/')
def main_menu():
    items = [
        {'label':u"Live", 'path':plugin.url_for("live_category_directory")},
        {'label':u"Drama", 'path':plugin.url_for("prog_list", cate='drama', page=0)},
        {'label':u"Entertainment", 'path':plugin.url_for("prog_list", cate='ent', page=0)},
        {'label':u"Music", 'path':plugin.url_for("prog_list", cate='music', page=0)},
        {'label':u"Society", 'path':plugin.url_for("prog_list", cate='society', page=0)},
        {'label':u"Feature program", 'path':plugin.url_for("prog_list", cate='special', page=0)},
        {'label':u"Cartoon", 'path':plugin.url_for("prog_list", cate='cartoon', page=0)},
        {'label':u"Movie", 'path':plugin.url_for("prog_list", cate='movie', page=0)},
    ]
    return items

@plugin.route('/live/category')
def live_category_directory():
    categories = ["지상파", "종합편성", "영화", "연예|오락", "어린이",
                  "스포츠|경제", "여성|취미", "다큐|종교"]
    return [{'label':cate, 'path':plugin.url_for("live_channel_category", cate=cate)} for cate in categories]

@plugin.route('/live/category/<cate>')
def live_channel_category(cate):
    url = scraper.ROOT_URL+urllib.quote("/live/"+cate)
    if plugin.get_setting('altParser', bool):
        info = scraper.parseLivePage2(url)
    else:
        info = scraper.parseLivePage(url)
    items = [{'label':item['name'],
             'path':plugin.url_for('play_video', url=item['url']),
             'thumbnail':item['thumbnail'],
            } for item in info]
    return plugin.finish(items, view_mode='thumbnail')

@plugin.route('/vod/<cate>/<page>/')
def prog_list(cate, page):
    plugin.log.debug("page : {}".format(page))
    pageN = 1 if page == '0' else int(page)
    url = scraper.ROOT_URL + "/{}?page={}".format(cate, pageN)
    plugin.log.debug(url)
    if plugin.get_setting('altParser', bool):
        result = scraper.parseProgList2(url)
    else:
        result = scraper.parseProgList(url)
    if cate == 'movie':
        items = [{'label':item['title'],
                 'path':plugin.url_for('play_video', url=item['url']),
                 'thumbnail':item['thumbnail'],
                } for item in result['link']]
    else:
        items = [{'label':item['title'],
                 'path':plugin.url_for('video_list', cate=item['category'], year=item['year'], progname=item['progname']),
                 'thumbnail':item['thumbnail'],
                } for item in result['link']]
    if 'prevpage' in result:
        items.append({'label':tPrevPage, 'path':plugin.url_for('prog_list', cate=cate, page=pageN-1), 'thumbnail':imgPrevPage})
    if 'nextpage' in result:
        items.append({'label':tNextPage, 'path':plugin.url_for('prog_list', cate=cate, page=pageN+1), 'thumbnail':imgNextPage})
    morepage = (page != '0')
    return plugin.finish(items, update_listing=morepage, view_mode='thumbnail')

@plugin.route('/vod/<cate>/program/<year>/<progname>/')
def video_list(cate, year, progname):
    url = scraper.ROOT_URL + "/{}/program/{}/{}".format(cate, year, urllib.quote(progname))
    plugin.log.debug(url)
    result = scraper.parseProgPage(url)
    items = [{'label':item['title'],
             'path':plugin.url_for('play_video', url=item['url']),
            } for item in result]
    return items

@plugin.route('/play/<url>')
def play_video(url):
    plugin.log.debug(url)
    vurl = scraper.extract_video_url(url)
    plugin.log.debug(vurl)
    plugin.play_video({'path':vurl, 'is_playable':True})

if __name__ == "__main__":
    plugin.run()

# vim:sw=4:sts=4:et
