# -*- coding: utf-8 -*-
"""
    BayKoreans
"""
from xbmcswift2 import Plugin
import urllib
import sys
import os
import re
from YDStreamExtractor import getVideoInfo

plugin = Plugin()
_L = plugin.get_string

plugin_path = plugin.addon.getAddonInfo('path')
lib_path = os.path.join(plugin_path, 'resources', 'lib')
sys.path.append(lib_path)

import baykoreans

tPrevPage = u"[B]<%s[/B]" % _L(30100)
tNextPage = u"[B]%s>[/B]" % _L(30101)

@plugin.route('/')
def main_menu():
    items = [
        {'label':u"방영 드라마", 'path':plugin.url_for("prog_list", cate='drama', page='-')},
        {'label':u"종영 드라마", 'path':plugin.url_for("prog_list", cate='drama_fin', page='-')},
        {'label':u"예능 | 오락", 'path':plugin.url_for("prog_list", cate='entertain', page='-')},
        {'label':u"시사 | 교양", 'path':plugin.url_for("prog_list", cate='current', page='-')},
        {'label':u"영화",        'path':plugin.url_for("prog_list", cate='movie', page='-')},
        {'label':u"애니 극장판", 'path':plugin.url_for("prog_list", cate='animation', page='-')},
        {'label':u"스포츠",      'path':plugin.url_for("prog_list", cate='sports', page='-')},
        {'label':u"뮤직비디오",  'path':plugin.url_for("prog_list", cate='music', page='-')},
    ]
    return items

@plugin.route('/category/<cate>/<page>/')
def prog_list(cate, page):
    pageN = 1 if page == '-' else int(page)
    url = baykoreans.ROOT_URL+'/index.php?mid=%s&page=%d' % (cate, pageN)
    if cate in ['movie', 'animation']:
        result = baykoreans.parseMovieList(url)
    elif plugin.get_setting('altParser', bool):
        result = baykoreans.parseProgList2(url)
    else:
        result = baykoreans.parseProgList(url)
    items = [{'label':item['title'],
             'path':plugin.url_for('video_list', cate=item['cate'], eid=item['id']),
             'thumbnail':item['thumbnail'],
            } for item in result['link']]
    if 'prevpage' in result:
        items.append({'label':tPrevPage, 'path':plugin.url_for('prog_list', cate=cate, page=pageN-1)})
    if 'nextpage' in result:
        items.append({'label':tNextPage, 'path':plugin.url_for('prog_list', cate=cate, page=pageN+1)})
    morepage = True if page != '-' else False
    return plugin.finish(items, update_listing=morepage)

@plugin.route('/episode/<cate>/<eid>/')
def video_list(cate, eid):
    play_Dailymotion = plugin.get_setting('byDailymotionPlugin', bool)
    dm_ptn = re.compile("http://.*dailymotion.com/video/(.*)$")
    info = baykoreans.parseVideoList(baykoreans.ROOT_URL+'/'+cate+'/'+eid)
    items = []
    prev_vurl = ""
    for item in info:
        vurl = item['url']
        is_playable = False
        if "dailymotion.com/" in item['url'] and play_Dailymotion:
            vurl = dm_ptn.sub(r"plugin://plugin.video.dailymotion_com/?url=\1&mode=playVideo", item['url'])
        if vurl != prev_vurl:
            items.append({'label':item['title'], 'path':plugin.url_for('play_video', url=vurl)})
            prev_vurl = vurl
    return items

@plugin.route('/play/<url>')
def play_video(url):
    plugin.log.debug(url)
    info = None
    if not url.startswith("plugin://"):
        quality = plugin.get_setting('qualityPref', int)
        info = getVideoInfo(url, quality=quality, resolve_redirects=True)
    if info:
        streams = info.streams()
        plugin.log.debug("num of streams: %d" % len(streams))
        from xbmcswift2 import xbmc, xbmcgui
        pl = xbmc.PlayList( xbmc.PLAYLIST_VIDEO )
        pl.clear()
        for stream in streams:
            li = xbmcgui.ListItem(stream['title'], iconImage="DefaultVideo.png")
            li.setInfo( 'video', { "Title": stream['title'] } )
            pl.add(stream['xbmc_url'], li)
        xbmc.Player().play(pl)
    else:
        plugin.log.warning('Fallback to '+url)
        plugin.play_video({'path':url, 'is_playable':True})
    return plugin.finish(None, succeeded=False)     # trick not to enter directory mode

if __name__ == "__main__":
    plugin.run()

# vim:sw=4:sts=4:et
