# -*- coding: utf-8 -*-
"""
    BayKoreans - Korea Drama/TV Shows Streaming Service
"""
import urllib2
import urlparse
import re
from bs4 import BeautifulSoup

ROOT_URL = 'http://baykoreans.net'
UserAgent = "Mozilla/5.0 (Windows; U; MSIE 9.0; Windows NT 9.0; en-US)"

def parseProgList(main_url):
    req = urllib2.Request(main_url)
    req.add_header('User-Agent', UserAgent)
    resp = urllib2.urlopen(req)
    doc = resp.read()
    resp.close()
    soup = BeautifulSoup(doc, from_encoding='utf-8')

    result = {'link':[]}
    for item in soup.findAll("td", {"class":"title"}):
        thumb = ""
        if item.div:
            thumb = item.div.img['src']
        if item.a:
            if not item.a.string:
                continue
            title = item.a.string.replace('&amp;','&')
            date,title = re.compile('^(\d*)\s*(.*)').search(title).group(1,2)
            if date:
                title = date + " " + title
            url = item.a['href']
            if 'index.php' in url:
                qs = urlparse.parse_qs(url.split('?',1)[1])
                cate = qs['mid'][0]
                id = qs['document_srl'][0]
            else:
                token = url.split('/')
                cate, id = token[-2:-1]
            result['link'].append({'title':title, 'cate':cate, 'id':id, 'thumbnail':thumb})

    # navigation
    cur = soup.find("ul", {"class":"pagination"}).find("li", {"class":"active"})
    p = cur.findPreviousSibling("li")
    if p.a and p.a.text.isdigit():
        url = ROOT_URL+p.a['href']
        result['prevpage'] = url
    p = cur.findNextSibling("li")
    if p.a and p.a.text.isdigit():
        url = ROOT_URL+p.a['href']
        result['nextpage'] = url
    return result

def parseProgList2(main_url):
    req = urllib2.Request(main_url)
    req.add_header('User-Agent', UserAgent)
    resp = urllib2.urlopen(req)
    doc = resp.read().decode("utf-8")
    resp.close()

    result = {'link':[]}
    for url, title in re.compile('<td class="title">\s*<a href="([^"]*)">([^<]*)</a>').findall(doc):
        title = title.replace('&amp;','&')
        date,title = re.compile('^(\d*)\s*(.*)').search(title).group(1,2)
        if date:
            title = date + " " + title
        if 'index.php' in url:
            qs = urlparse.parse_qs(url.split('?',1)[1])
            cate = qs['mid'][0]
            id = qs['document_srl'][0]
        else:
            token = url.split('/')
            cate, id = token[-2:-1]
        result['link'].append({'title':title, 'cate':cate, 'id':id, 'thumbnail':None})

    # navigation
    navipt = re.compile('<ul class="pagination">(.*?)</ul>', re.S).search(doc).group(1)
    match = re.compile('<li><a href="([^"]*)">\d+</a></li>\s*<li class="active">').search(navipt)
    if match:
        url = ROOT_URL+match.group(1)
        result['prevpage'] = url
    match = re.compile('<li class="active">.*?<li><a href="([^"]*)">', re.S).search(navipt)
    if match:
        url = ROOT_URL+match.group(1)
        result['nextpage'] = url
    return result

def parseMovieList(main_url):
    req = urllib2.Request(main_url)
    req.add_header('User-Agent', UserAgent)
    resp = urllib2.urlopen(req)
    doc = resp.read()
    resp.close()
    soup = BeautifulSoup(doc, from_encoding='utf-8')

    result = {'link':[]}
    for item in soup.findAll("div", {"class":"title"}):
        url = item.a['href']
        # skip items which is not links to the movie
        if not "movie" in url and not "animation" in url:
            continue
        title = item.a.string.replace('&amp;','&')
        if 'index.php' in url:
            qs = urlparse.parse_qs(url.split('?')[1])
            cate = qs['mid'][0]
            id = qs['document_srl'][0]
        else:
            token = url.split('/')
            cate, id = token[-2:-1]

        thumb = item.findNextSibling("div", {"class":"thumb"}).find('img')['src']
        result['link'].append({'title':title, 'cate':cate, 'id':id, 'thumbnail':thumb})

    # navigation
    cur = soup.find("ul", {"class":"pagination"}).find("li", {"class":"active"})
    p = cur.findPreviousSibling("li")
    if p.a and p.a.text.isdigit():
        url = ROOT_URL+p.a['href']
        result['prevpage'] = url
    p = cur.findNextSibling("li")
    if p.a and p.a.text.isdigit():
        url = ROOT_URL+p.a['href']
        result['nextpage'] = url
    return result

def parseMovieList2(main_url):
    req = urllib2.Request(main_url)
    req.add_header('User-Agent', UserAgent)
    resp = urllib2.urlopen(req)
    doc = resp.read().decode("utf-8")
    resp.close()

    result = {'link':[]}
    for url, title in re.compile('<div class="title" *>\s*<a href="([^"]*)" *>([^<]*)</a>').findall(doc):
        # skip items which is not links to the movie
        if not "movie" in url and not "animation" in url:
            continue
        title = title.replace('&amp;','&')
        if 'index.php' in url:
            qs = urlparse.parse_qs(url.split('?')[1])
            cate = qs['mid'][0]
            id = qs['document_srl'][0]
        else:
            token = url.split('/')
            cate, id = token[-2:-1]

        result['link'].append({'title':title, 'cate':cate, 'id':id, 'thumbnail':None})

    # navigation
    navipt = re.compile('<ul class="pagination">(.*?)</ul>', re.S).search(doc).group(1)
    match = re.compile('<li><a href="([^"]*)">\d+</a></li>\s*<li class="active">').search(navipt)
    if match:
        url = ROOT_URL+match.group(1)
        result['prevpage'] = url
    match = re.compile('<li class="active">.*?<li><a href="([^"]*)">', re.S).search(navipt)
    if match:
        url = ROOT_URL+match.group(1)
        result['nextpage'] = url
    return result

def parseVideoList(main_url):
    req = urllib2.Request(main_url)
    req.add_header('User-Agent', UserAgent)
    doc = urllib2.urlopen(req).read().decode('string-escape')
    doc = re.compile(r'<script language="javascript">document\.write\(unescape\("(.*?)"\)\);</script>', re.S).sub(r"\g<1>", doc)
    soup = BeautifulSoup(doc)
    result = []
    for item in soup.findAll('a', {'class':'xLarge'}):
        url = item['href']
        if url.startswith('//'):
            url = "http:" + url
        elif not url.startswith('http://'):
            url = ROOT_URL + url
        title = item.span.string.split('|')[-1].strip()
        result.append({'title':title, 'url':extract_video_url(url)})
    return result

def parseVideoList2(main_url):
    req = urllib2.Request(main_url)
    req.add_header('User-Agent', UserAgent)
    doc = urllib2.urlopen(req).read().decode('string-escape')
    doc = re.compile(r'<script language="javascript">document\.write\(unescape\("(.*?)"\)\);</script>', re.S).sub(r"\g<1>", doc)
    doc = doc.decode('utf-8')
    result = []
    for url, title in re.compile('<a href="([^"]*)" class="[^"]*xLarge" target="_blank"><span>([^<]*)').findall(doc):
        if url.startswith('//'):
            url = "http:" + url
        elif not url.startswith('http://'):
            url = ROOT_URL + url
        title = title.split('|')[-1].strip()
        result.append({'title':title, 'url':extract_video_url(url)})
    return result

def extract_video_url(url):
    base_url = url[ : url.find('/',7)] 
    vid_url = None
    if '/?xink=' in url:
        qs = urlparse.parse_qs(url.split('?',1)[1])
        xink = qs['xink'][0]
        vid_url = None
        if '/dmotion/' in url or '/emotion/' in url:
            vid_url = "http://www.dailymotion.com/video/"+xink
        elif '/tudou.y/' in url:
            vid_url = "http://vr.tudou.com/v2proxy/v2?it=%s&st=52&pw=" % xink
        elif '/tudou/' in url:
            vid_url = xink.replace("//","/")
        elif '/sohu/' in url:
            vid_url = "http://my.tv.sohu.com/u/vw/"+xink
        elif '/xink' in url or '/?xink' in url:
            vid_url = xink
        elif '/linkbank/' in url:
            vid_url = xink
        else:
            print "Unsupported URL, "+url
            return None
    elif '/?link=' in url:
        req = urllib2.Request(url)
        req.add_header('User-Agent', UserAgent)
        doc = urllib2.urlopen(req).read()
        xink = re.search(r'\)\);</script>([^>]*)">', doc).group(1)
        vid_url = base_url+"/linkout/getfile/"+xink
    elif '/xoxo/?' in url or '/xixi/?' in url:
        vid_url = url.split('?',1)[1].split('&')[0]
    else:
        vid_url = url

    # normalize url
    if 'dailymotion.com' in vid_url:
        vid_url = vid_url.replace('/embed/video/', '/video/')
        vid_url = vid_url.split('?')[0]
    elif 'tudou.com/v/' in vid_url:
        vid_url = vid_url.replace('tudou.com/v/', 'tudou.com/programs/view/')

    return vid_url

if __name__ == "__main__":
    print parseProgList(ROOT_URL+"/index.php?mid=entertain&page=2")
    print parseProgList2(ROOT_URL+"/index.php?mid=entertain&page=2")
    print parseMovieList(ROOT_URL+"/index.php?mid=animation&page=2")
    print parseMovieList(ROOT_URL+"/index.php?mid=animation&page=2")
    print parseVideoList(ROOT_URL+"/entertain/2649497")
    print parseVideoList2(ROOT_URL+"/entertain/2649497")

# vim:sts=4:sw=4:et
