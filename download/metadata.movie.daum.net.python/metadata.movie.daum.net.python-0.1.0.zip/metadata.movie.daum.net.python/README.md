## Daum Movie Python scraper for Kodi

This is revised version of metadata.movie.daum.net scraper to Python.

It fetches movie information from [movie.daum.net](http://movie.daum.net).
