# -*- coding: utf-8 -*-
__author__ = "Dong-gyun Ham"
__copyright__ = "Copyright 2015"
__license__ = "GPL"
__email__ = "irow14@gmail.com"


import os
import urllib
import xbmcplugin, xbmcgui, xbmcaddon
from urlparse import parse_qs


__addon__ = xbmcaddon.Addon()
__language__  = __addon__.getLocalizedString
__profile__ = xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__ = __addon__.getAddonInfo('version')
__id__ = __addon__.getAddonInfo('id')
__name__ = __addon__.getAddonInfo('name')
__cwd__ = xbmc.translatePath( __addon__.getAddonInfo('path') )
__lib__ = os.path.join( __cwd__, 'resources', 'lib' )
sys.path.append(__lib__)

from pooqCore import *

# root 
def dp_main():
	addon_log('Display main!')

	# login process
	(pooq_id, pooq_pw) = get_settings_login_info()

	if not (pooq_id and pooq_pw):
		dialog = xbmcgui.Dialog()
		ret = dialog.yesno(__name__, __language__(30201).encode('utf8'), __language__(30202).encode('utf8'))
		if ret == True:
			__addon__.openSettings()
			sys.exit()

	# check login
	if pooq_id and pooq_pw:
		if not Pooq().GetCredential( pooq_id, pooq_pw ):
			# login failed
			addon_noti( __language__(30203).encode('utf8') )

	items = [ {'title':__language__(30009).encode('utf8'), 'category':'Live'}, {'title':__language__(30004).encode('utf8'), 'category':'VOD'}, {'title':__language__(30005).encode('utf8'), 'category':'Movie'} ]

	for item in items:
		title = item['title']
		cate = item['category']
		add_dir(title, None, None, None, None, cate, 0)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))


def dp_live_list( p ):
	addon_log('Display Live List!')
	index = int(p['index'])
	items = Pooq().GetLiveList()

	for item in items:
		ch_nm = item['channelTitle'].encode('utf-8')
		pgm_nm = item['title'].encode('utf-8')
		img = item['image']
		if item['isLicenceAvaliable'] == 'X': ch_id = ''
		else: ch_id = item['id']
		qualityList = item['qualityList'][0]['quality']
		qualityList = "|".join(qualityList)
		add_dir(ch_nm, pgm_nm, ch_id, img, qualityList, 'play_live', (index + 1), False)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))


def play_live( p ):
	addon_log('Play Live!')
	surl = None
	success = False
	ch_nm = p['label']
	try:
		ch_id = p['c_id']
	except:
		ch_id = None
	if ch_id:
		# select quality
		qualityList = p['properties'].split('|')
		quality = choose_stream_quality( qualityList )

		# get stream url
		if quality: surl = Pooq().GetLiveStreamUrl(ch_id, quality)
	else:
		addon_noti( __language__(30204).encode('utf-8') )
	if surl:
		success = True
		if 'playduration=180' in surl: addon_noti( __language__(30001).encode('utf-8') )
	else:
		surl = ''
	item = xbmcgui.ListItem(path=surl)
	item.setInfo(type="Video", infoLabels={'title': ch_nm})
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), success, item)


def dp_vod_list( p ):
	addon_log('Display VOD List!')
	index = int(p['index'])
	mode = p['mode']
	pooq = Pooq()
	funcs_list = {
					'VOD':( pooq.GetVODGenres, pooq.GetVODList ),
					'Movie':( pooq.GetMovieGenres, pooq.GetMovieList )
				 }
	funcs = funcs_list[mode]

	if index == 0:
		items = [ [__language__(30006).encode('utf8'),'search','s'], 
				  [__language__(30007).encode('utf8'),'all','d'], 
				  [__language__(30008).encode('utf8'),'all','h'] ] #, ['다국어','l'] 
		for item in items:
			title = item[0]
			genre = item[1]
			orderby = item[2]
			add_dir(title, None, genre, None, orderby, mode, (index + 1))

		getgenre_func = funcs[0]
		genres = getgenre_func()

		for item in genres:
			title = item['genreTitle'].encode('utf-8')
			genre = item['genreCode']
			orderby = 'd'
			add_dir(title, None, genre, None, orderby, mode, (index + 1))

	else:
		genre = p['c_id']
		items = []

		if genre == 'search':
			# search
			kwd = get_keyboard_input(__language__(30003).encode('utf-8'))
			if kwd:
				items = pooq.Search(mode, kwd, index)
			else:
				return
		else:
			orderby = p['properties']
			getlist_func = funcs[1]
			items = getlist_func(genre, orderby, index)
		
		for item in items:
			if mode == 'VOD':
				pgm_nm = item['title'].encode('utf-8')
				freq = item['episodeNo'].encode('utf-8')
				if freq:
					title = '%s %s회' % (pgm_nm, freq)
				else:
					title = pgm_nm
				item_id = item['id']
				program_id = item['programId']
				img = item['image'].replace('.jpg','_11.jpg')
				add_dir(title, None, item_id, img, program_id, 'play_vod', (index + 1), False)
			elif mode == 'Movie':
				title = item['title'].encode('utf-8')
				item_id = item['id']
				img = item['image'].replace('.jpg','_210.jpg')
				add_dir(title, None, item_id, img, None, 'play_vod', (index + 1), False)

		# more page
		if (len(items) == 30) and (len(items) != 0):
			add_dir('[B]%s >>[/B]' % __language__(30002).encode('utf-8'), None, genre, None, orderby, mode, (index + 1) )
	xbmcplugin.endOfDirectory(int(sys.argv[1]))



def play_vod( p ):
	addon_log('Play VOD!')
	success = False
	surl = None
	title = p['label']
	program_id = p['properties']
	item_id = p['c_id']
	pooq = Pooq()

	if program_id != 'None':
		vod_info = pooq.GetVODInfo( program_id, item_id )
		vod_type = 'vod'
	else:
		vod_info = pooq.GetMovieInfo( item_id )
		vod_type = 'movie'

	if vod_info:
		# select quality
		qualityList = vod_info['resolutions'][0]['resolution']
		quality = choose_stream_quality( qualityList )

		# get stream url
		if quality: surl = pooq.GetVODStreamUrl( vod_type, item_id, quality )

		if surl:
			success = True
			if 'playduration=180' in surl: addon_noti( __language__(30001).encode('utf-8') )
		else:
			surl = ''
		item = xbmcgui.ListItem(path=surl)
		item.setInfo(type="Video", infoLabels={'title': title})
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), success, item)


def get_settings_login_info():
	# 설정에서 id, pwd 가져오기
	uid = __addon__.getSetting( 'id' )
	pwd = __addon__.getSetting( 'pwd' )
	return (uid, pwd)


def get_keyboard_input( heading, hidden=False ):
	input_text = None
	kb = xbmc.Keyboard()
	kb.setHeading( heading )
	if hidden: kb.setHiddenInput( hidden )
	xbmc.sleep(1000)
	kb.doModal()
	if (kb.isConfirmed()):
		input_text = kb.getText()
	return input_text


def choose_stream_quality( quality_list ):
	isManualQuality = __addon__.getSetting('manual_quality')

	if (isManualQuality == 'true'):
		quality = item_selecting( quality_list )
	else:
		def_quality_list = [ "5000", "2000", "1000", "500" ]
		sel_quality_idx = int(__addon__.getSetting('selected_quality'))
		sel_quality = def_quality_list[sel_quality_idx]
		if sel_quality in quality_list:
			quality = sel_quality
		else:
			quality = quality_list[0]
	return quality



def item_selecting( items ):
	choose_idx = xbmcgui.Dialog().select(__language__(30205).encode('utf-8'), items)
	if choose_idx > -1: sel_item = items[choose_idx]
	else: sel_item = None
	return sel_item


def addon_noti(sting):
	try:
		dialog = xbmcgui.Dialog()
		dialog.notification(__name__, sting)
	except:
		addon_log('addonException: addon_noti')


def addon_log(string):
	try:
		log_message = string.encode('utf-8', 'ignore')
	except:
		log_message = 'addonException: addon_log'
	xbmc.log("[%s-%s]: %s" %(__id__, __version__, log_message),level=xbmc.LOGDEBUG) #LOGNOTICE, LOGDEBUG



def add_dir(label, sublabel, c_id, img, properties, mode, index, isfolder=True):
	params = {'label':label, 'c_id': c_id, 'mode': mode, 'index':index, 'properties':properties}
	url = '%s?%s' %(sys.argv[0], urllib.urlencode(params))
	if not img: img = 'DefaultFolder.png'
	if sublabel:
		title = '%s < %s >' % (label, sublabel)
	else:
		title = label
	listitem = xbmcgui.ListItem(title, thumbnailImage=img)
	if not isfolder: listitem.setProperty('IsPlayable', 'true')
	xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, isfolder)



def get_params():
	p = parse_qs(sys.argv[2][1:])
	for i in p.keys():
		p[i] = p[i][0]
	return p

	
params = get_params()


try:
	mode = params['mode']
except:
	mode = None

if mode == None:
	dp_main()

elif mode == 'Live':
	dp_live_list( params )

elif mode == 'play_live':
	play_live( params )

elif mode in ['VOD', 'Movie']:
	dp_vod_list( params )

elif mode == 'play_vod':
	play_vod( params )

else:
	addon_log('################### funcs not define ###################')

