import urllib, urllib2, cookielib
import os
import xbmc, xbmcaddon
import simplejson
import xml.dom.minidom


__profile__ = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
CREDENTIALDATA = xbmc.translatePath( os.path.join( __profile__, 'credential.dat') )


class Client( object ):
	def __init__( self, cookie=None ):
		self.MyCookie = cookielib.LWPCookieJar()
		self.MyCookieFile = cookie
		if self.MyCookieFile:
			try:
				self.MyCookie.load( self.MyCookieFile, ignore_discard=True )
			except:
				pass
		self.Opener = urllib2.build_opener( urllib2.HTTPCookieProcessor(self.MyCookie) )
		self.Opener.addheaders = [('User-Agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/600.1.25 (KHTML, like Gecko) Version/8.0 Safari/600.1.25')]
		urllib2.install_opener(self.Opener)

	def AddHeaders( self, headers ):
		self.Opener.addheaders = headers

	def Request( self, url, postdata=None ):
		#print "::Request - url: %s" % url
		if postdata:
			req = self.Opener.open( url, postdata )
		else:
			req = self.Opener.open( url )
		response = req.read()
		req.close()
		return response

	def ClearCookie( self ):
		self.MyCookie.clear()

	def SaveCookie( self ):
		self.MyCookie.save( self.MyCookieFile, ignore_discard=True )


	def Login( self, url, data=None ):
		self.ClearCookie()
		req = self.Opener.open( url, data )
		data = req.read()
		req.close()
		self.SaveCookie()
		return data
		

class Pooq( object ):
	def __init__( self ):
		self.ApiUrl = 'https://wapie.pooq.co.kr'
		self.client = Client()
		self.limit = 30


	def GetCredential( self, user_id, user_pw ):
		isLogin = False
		try:
			url = '%s/v1/login/?deviceTypeId=pc&marketTypeId=generic&apiAccessCredential=dummykey&credential=&mode=id&id=%s&password=%s' % (self.ApiUrl, user_id, user_pw)
			req = self.client.Request( url, ' ' )
			req_json = simplejson.loads( req )
			credential_temp = req_json['result']['credential']
			if credential_temp:
				credential = urllib.quote_plus(credential_temp)
				isLogin = True
		except:
			credential = 'none'
		write_file( CREDENTIALDATA, credential )
		return isLogin


	def GetLiveList( self ):
		try:
			url = '%s/v1/lives?apiAccessCredential=dummykey&orderby=g&offset=0&deviceTypeId=pc&mode=all&genere=all&marketTypeId=generic&limit=100&credential=none' % self.ApiUrl
			req = self.client.Request( url )
			req_json = simplejson.loads( req )
			result = req_json['result']['list']
		except:
			result = []
		return result


	def GetLiveInfo( self, channelID ):
		try:
			url = '%s/v1/lives/%s?deviceTypeId=pc&marketTypeId=generic&apiAccessCredential=dummykey&credential=none' % ( self.ApiUrl, channelID )
			req = self.client.Request( url )
			req_json = simplejson.loads( req )
			result = req_json['result']
		except:
			result = None
		return result


	def GetLiveStreamUrl( self, channelID, quality ):
		result = None
		credential = load_file( CREDENTIALDATA )
		try:
			url = '%s/v1/lives/%s/url?deviceTypeId=ios&marketTypeId=generic&deviceModelId=none&credential=%s&quality=%s' % (self.ApiUrl, channelID, credential, quality )
			req = self.client.Request( url )
			req_json = simplejson.loads( req )
			result = req_json['result']['url']
		except:
			pass
		return result


	def Search( self, vod_type, keyword, pageNo=1 ):
		try:
			offset = (pageNo - 1) * self.limit
			url = '%s/v1/search/%s/?deviceTypeId=pc&marketTypeId=generic&apiAccessCredential=dummykey&offset=%d&limit=%d&orderby=C&query=%s' % (self.ApiUrl, vod_type, offset, (self.limit * 10), keyword)
			req = self.client.Request( url )
			req_json = simplejson.loads( req )
			result = req_json['result']['list']
		except:
			result = []
		return result


	def GetVODGenres( self ):
		try:
			url = '%s/v1/vodgenres/?deviceTypeId=pc&apiAccessCredential=dummykey&marketTypeId=generic' % self.ApiUrl
			req = self.client.Request( url )
			req_json = simplejson.loads( req )
			result = req_json['result']['list']
		except:
			result = None
		return result



	def GetVODList( self, genre, cate, pageNo=1 ):
		try:
			offset = (pageNo - 1) * self.limit
			url = '%s/v1/vods/%s/?deviceTypeId=pc&apiAccessCredential=dummykey&offset=%d&limit=%d&orderby=%s&marketTypeId=generic&isFree=all&channelId=ANY' % (self.ApiUrl, genre, offset, self.limit, cate)
			req = self.client.Request( url )
			req_json = simplejson.loads( req )
			result = req_json['result']['list']
		except:
			result = []
		return result


	def GetVODInfo( self, programid, itemid ):
		try:
			url = '%s/v1/vods/all/%s/%s/1?deviceTypeId=pc&marketTypeId=generic&apiAccessCredential=dummykey&credential=none' % ( self.ApiUrl, programid, itemid )
			req = self.client.Request( url )
			req_json = simplejson.loads( req )
			result = req_json['result']
		except:
			result = None
		return result


	def GetMovieGenres( self ):
		try:
			url = '%s/v1/moviegenres/?deviceTypeId=pc&apiAccessCredential=dummykey&marketTypeId=generic' % self.ApiUrl
			req = self.client.Request( url )
			req_json = simplejson.loads( req )
			result = req_json['result']['list']
		except:
			result = None
		return result


	def GetMovieList( self, genre, cate, pageNo=1 ):
		try:
			offset = (pageNo - 1) * self.limit
			url = '%s/v1/movies/%s?deviceTypeId=pc&apiAccessCredential=dummykey&marketTypeId=generic&offset=%d&limit=%d&orderby=%s&isKorean=all&isFree=all' % (self.ApiUrl, genre, offset, self.limit, cate)
			req = self.client.Request( url )
			req_json = simplejson.loads( req )
			result = req_json['result']['list']
		except:
			result = []
		return result


	def GetMovieInfo( self, itemid ):
		try:
			url = '%s/v1/movies/all/%s/1?deviceTypeId=pc&marketTypeId=generic&apiAccessCredential=dummykey&credential=none' % ( self.ApiUrl, itemid )
			req = self.client.Request( url )
			req_json = simplejson.loads( req )
			result = req_json['result']
		except:
			result = None
		return result


	def GetVODStreamUrl( self, vod_type, itemid, quality ):
		result = None
		credential = load_file( CREDENTIALDATA )
		try:
			url = '%s/v1/permission?deviceTypeId=pc&marketTypeId=generic&deviceModelId=none&credential=%s&quality=%s&type=%s&cornerId=1&id=%s&action=stream' % (self.ApiUrl, credential, quality, vod_type, itemid)
			req = self.client.Request( url )
			req_json = simplejson.loads( req )
			result = req_json['result']['url']
		except:
			pass
		return result



def load_file( filename ):
	try:
		with open(filename, "r") as f:
			data = f.read()
		f.close()
	except:
		data = None
	return data

def write_file( filename, data ):
	try:
		with open(filename, "w") as f:
			f.write( str(data) )
		f.close()
	except:
		pass

