# -*- coding: utf-8 -*-
"""
    ondemandkorea.com

    /includes/latest.php?cat=<name>
    /includes/episode_page.php?cat=<name>&id=<num>&page=<num>
"""
import requests
import re
import json
from bs4 import BeautifulSoup
import time
import random

root_url = "http://www.ondemandkorea.com"
#cat_json_url = root_url+"/includes/categories/{genre:s}_{language:s}.json?cb={timestamp:d}"
cat_json_url = root_url+"/includes15/categories/{genre:s}_{language:s}"
# mimic iPad
default_hdr = {
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
    'Accept-Encoding': 'none',
    'Connection': 'keep-alive'}
tablet_UA = 'Mozilla/5.0 (Linux; Android 4.0.4; Galaxy Nexus Build/IMM76B) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.133 Safari/535.19'

eplist_url = "/includes/episode_page.php?cat={program:s}&id={videoid:s}&page={page:d}"

bitrate2resolution = {
    #196:'180',
    #396:'240',
    #796:'300',
    #1296:'360',
    1596:'480',
    2296:'720',
    3792:'1080',
}

def loginSess(email, passwd):
    s = requests.Session()
    r = s.post(root_url+"/includes15/login", {"email":email,"password":passwd,"isRemember":False,"rememberme":"","next":"/"})
    if '"success"' not in r.text:
        return None
    return s.cookies

def parseTop(koPage=True):
    hdr = default_hdr
    cookies = None
    if koPage:
        hdr['Accept-Langauge'] = 'ko'
        cookies = dict(language='ko')
    r = requests.get(page_url, headers=hdr, cookies=cookies)
    html = r.text
    soup = BeautifulSoup(html)
    items = []
    for node in soup.find('div', {'id':'menu-category'}).findAll(lambda tag: tag.name=='a' and '.html' in tag['href']):
        items.append(node['href'])
    return items

def parseGenre(genre, koPage=True, sort=None):
    ts = int(time.mktime(time.gmtime()) / 1000 / 60 / 5)
    lang = "ko" if koPage else "en"
    #url = cat_json_url.format(genre=genre, language=lang, timestamp=ts)
    url = root_url+"/includes15/categories/{genre}_{language}".format(genre=genre, language=lang)
    r = requests.get(url, headers=default_hdr)
    jstr = r.text
    obj = json.loads(jstr)
    # sort
    if sort == "popular":
        obj.sort(key=lambda node:node['popular'], reverse=True)
    elif sort == "latest":
        obj.sort(key=lambda node:int(node['latest']), reverse=True)
    # result
    items = []
    for item in obj:
        items.append({'title':item['title'], 'name':item['cat_name'], 'post':item['post_name'], 'thumbnail':item['poster_url']})
    return items

def extractEpisodeDataUrlFromPage(page_url):
    if page_url[0] == '/':
        page_url = root_url + page_url
    r = requests.get(page_url, headers=default_hdr)
    epinfo_tmpl = re.search("setPageDataUrl\('([^']*)'\)", r.text).group(1)
    return root_url + epinfo_tmpl.replace("-00000000", "1")

def parseEpisodePage(url):
    r = requests.get(url, headers=default_hdr)
    jstr = r.text
    obj = json.loads(jstr)
    result = {'episode':[]}
    for item in obj['list']:
        result['episode'].append({'title':item['title'], 'broad_date':item['on_air_date'], 'url':root_url+item['url'], 'thumbnail':item['thumbnail']})
    # navigation
    page = obj['current_page']
    base_url = url.rsplit('_',1)[0]
    if page > 1:
        result['prevpage'] = base_url + "_" +  str(page-1)
    
        result['nextpage'] = base_url + "_" +  str(page+1)
    return result

#
def extractMovieDataUrlFromPage(page_url, koPage=True, cj=None):
    hdr = default_hdr
    cookies = None
    if koPage:
        hdr['Accept-Langauge'] = 'ko'
        cookies = dict(language='ko')
    if cj:
        s = requests.Session()
        s.cookies = cj
        r = s.get(page_url, headers=hdr)
    else:
        r = requests.get(page_url, headers=hdr, cookies=cookies)
    sub_url = re.search('getJSON\("([^"]*)"', r.text).group(1)
    return root_url+sub_url

def parseMoviePage(url, sort=None):
    r = requests.get(url, headers=default_hdr)
    jstr = r.text
    obj = json.loads(jstr)
    # sort
    if sort == "popular":
        obj.sort(key=lambda node:node['popular'], reverse=True)
    elif sort == "latest":
        obj.sort(key=lambda node:int(node['latest']), reverse=True)
    # result
    result = {'movie':[]}
    for item in obj:
        result['movie'].append({'title':item['title'], 'year':str(item['movie_year']), 'url':root_url+item['post_name'], 'thumbnail':item['poster_url']})
    return result

# m3u8
def extractStreamUrl(page_url, koPage=True, referer=None, cj=None, fallthru=False):
    hdr = default_hdr
    cookies = None
    if koPage:
        hdr['Accept-Langauge'] = 'ko'
        cookies = dict(language='ko')
    if referer:
        hdr['Referer'] = referer
    if cj:
        s = requests.Session()
        s.cookies = cj
        r = s.get(page_url, headers=hdr)
    else:
        r = requests.get(page_url, headers=hdr, cookies=cookies)
    html = r.text
    vid_title = re.compile('<meta property="og:title" content="(.*?)"', re.S).search(html).group(1).strip()
    #vid_title = re.compile('<p class="episode_title".*?>(.*?)</div>', re.S).search(html).group(1).strip()
    match = re.compile("""(http[^'"]*m3u8)""").search(html, re.I|re.U)
    vid_url = match.group(1) if match else None
    # fall-thru
    if not vid_url and fallthru:
        date_ptn = re.compile("- (\d+)/(\d+)/(\d+)\s*</p>")
        match = date_ptn.search(html)
        if match:
            yrmo = "%s%s"% match.group(3,1)
            info_ptn = re.compile("var dfp_dict = {\s*'category':\s*'(.+?)',\s*'program':\s*'(.+?)',\s*'episode':\s*'(.+?)',", re.S)
            match = info_ptn.search(html)
            vid_url = "https://hls.ondemandkorea.com/v1/{}/%s/%s/%s/playlist_720.m3u8".format(yrmo) % match.group(1,2,3) if match else None
    if not vid_url:
        import codecs
        codecs.open("/tmp/dbg.html","w","utf-8").write(html)
        return None
    videos = dict()
    if '_1080.m3u8' in vid_url:
        videos[3792] = {'url':vid_url}
    elif '_720.m3u8' in vid_url:
        for bitrate, resolution in bitrate2resolution.iteritems():
            videos[resolution] = {'url':vid_url.replace('720', resolution)}
    return {'title':vid_title, 'videos':videos}

# mp4
def extractVideoUrl(page_url, koPage=True, referer=None):
    hdr = default_hdr
    hdr['User-Agent'] = tablet_UA
    cookies = None
    if koPage:
        hdr['Accept-Langauge'] = 'ko'
        cookies = dict(language='ko')
    if referer:
        hdr['Referer'] = referer
    r = requests.get(page_url, headers=hdr, cookies=cookies)
    html = r.text
    vid_title = re.compile('<meta property="og:title" content="(.*?)"', re.S).search(html).group(1).strip()
    match = re.compile("""(http[^'"]*mp4)""").search(html)
    if not match:
        return None
    vid_url = match.group(1)
    videos = dict()
    for bitrate, resolution in bitrate2resolution.iteritems():
        videos[resolution] = {'url':vid_url.replace('360p', resolution)}
    return {'title':vid_title, 'videos':videos}

if __name__ == "__main__":
    import sys
    cj = None
    if len(sys.argv) == 3:
        cj = loginSess(sys.argv[1], sys.argv[2])
        print(cj)
    #print(parseTop())
    #parseGenre( "variety", sort="popular" )
    #print(parseGenre( "variety" ))
    #print(parseEpisodePage( root_url+"/includes15/episode_page/infinite-challenge_63032_ko_1" ))
    #print(extractStreamUrl( root_url+"/infinite-challenge-e452.html" ))
    #print(extractVideoUrl( root_url+"/infinite-challenge-e452.html" ))
    #print(parseEpisodePage2( root_url+"/mystery-music-show-mask-king-e31.html" ))
    #print(extractVideoUrl( root_url+"/mystery-music-show-mask-king-e31.html" ))
    print(extractStreamUrl( root_url+"/the-penthouse-2-e03.html", cj=cj ))
    print(extractStreamUrl( root_url+"/city-fishers-2-e03-1.html" ))
    #-- Movie
    #url = extractMovieDataUrlFromPage(root_url+"/pay-per-view")
    #print(url)
    #print(parseMoviePage(url, sort="popular"))
    #print(extractStreamUrl( root_url+"/peninsula.html" ))

# vim:sw=4:sts=4:et
