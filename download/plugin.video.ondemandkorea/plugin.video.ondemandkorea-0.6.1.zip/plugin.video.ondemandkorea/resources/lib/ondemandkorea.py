# -*- coding: utf-8 -*-
"""
    ondemandkorea.com

    /includes/latest.php?cat=<name>
    /includes/episode_page.php?cat=<name>&id=<num>&page=<num>
"""
import requests
import re
import json
from bs4 import BeautifulSoup
import time
import random

root_url = "http://www.ondemandkorea.com"
#cat_json_url = root_url+"/includes/categories/{genre:s}_{language:s}.json?cb={timestamp:d}"
cat_json_url = root_url+"/includes15/categories/{genre:s}_{language:s}"
# mimic iPad
default_hdr = {
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
    'Accept-Encoding': 'none',
    'Connection': 'keep-alive'}
tablet_UA = 'Mozilla/5.0 (Linux; Android 4.0.4; Galaxy Nexus Build/IMM76B) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.133 Safari/535.19'

eplist_url = "/includes/episode_page.php?cat={program:s}&id={videoid:s}&page={page:d}"

bitrate2resolution = {
    #196:'180p',
    #396:'240p',
    #796:'300p',
    #1296:'360p',
    1596:'480p',
    2296:'720p',
    3792:'1080p',
}

def parseTop(koPage=True):
    hdr = default_hdr
    cookies = None
    if koPage:
        hdr['Accept-Langauge'] = 'ko'
        cookies = dict(language='ko')
    r = requests.get(page_url, headers=hdr, cookies=cookies)
    html = r.text
    soup = BeautifulSoup(html)
    items = []
    for node in soup.find('div', {'id':'menu-category'}).findAll(lambda tag: tag.name=='a' and '.html' in tag['href']):
        items.append(node['href'])
    return items

def parseGenre(genre, koPage=True, sort=None):
    ts = int(time.mktime(time.gmtime()) / 1000 / 60 / 5)
    lang = "ko" if koPage else "en"
    #url = cat_json_url.format(genre=genre, language=lang, timestamp=ts)
    url = root_url+"/includes15/categories/{genre}_{language}".format(genre=genre, language=lang)
    r = requests.get(url, headers=default_hdr)
    jstr = r.text
    obj = json.loads(jstr)
    # sort
    if sort == "popular":
        obj.sort(key=lambda node:node['popular'], reverse=True)
    elif sort == "latest":
        obj.sort(key=lambda node:int(node['latest']), reverse=True)
    # result
    items = []
    for item in obj:
        items.append({'title':item['title'], 'name':item['cat_name'], 'post':item['post_name'], 'thumbnail':item['poster_url']})
    return items

def extractEpisodeDataUrlFromPage(page_url):
    if page_url[0] == '/':
        page_url = root_url + page_url
    r = requests.get(page_url, headers=default_hdr)
    epinfo_tmpl = re.search("setPageDataUrl\('([^']*)'\)", r.text).group(1)
    return root_url + epinfo_tmpl.replace("-00000000", "1")

def parseEpisodePage(url):
    r = requests.get(url, headers=default_hdr)
    jstr = r.text
    obj = json.loads(jstr)
    result = {'episode':[]}
    for item in obj['list']:
        result['episode'].append({'title':item['title'], 'broad_date':item['on_air_date'], 'url':root_url+item['url'], 'thumbnail':item['thumbnail']})
    # navigation
    page = obj['current_page']
    base_url = url.rsplit('_',1)[0]
    if page > 1:
        result['prevpage'] = base_url + "_" +  str(page-1)
    
        result['nextpage'] = base_url + "_" +  str(page+1)
    return result

#
def extractMovieDataUrlFromPage(page_url, koPage=True):
    hdr = default_hdr
    cookies = None
    if koPage:
        hdr['Accept-Langauge'] = 'ko'
        cookies = dict(language='ko')
    r = requests.get(page_url, headers=hdr, cookies=cookies)
    sub_url = re.search('getJSON\("([^"]*)"', r.text).group(1)
    return root_url+sub_url

def parseMoviePage(url, sort=None):
    r = requests.get(url, headers=default_hdr)
    jstr = r.text
    obj = json.loads(jstr)
    # sort
    if sort == "popular":
        obj.sort(key=lambda node:node['popular'], reverse=True)
    elif sort == "latest":
        obj.sort(key=lambda node:int(node['latest']), reverse=True)
    # result
    result = {'movie':[]}
    for item in obj:
        result['movie'].append({'title':item['title'], 'year':str(item['movie_year']), 'url':root_url+item['post_name'], 'thumbnail':item['poster_url']})
    return result

# m3u8
def extractStreamUrl(page_url, koPage=True, referer=None):
    hdr = default_hdr
    cookies = None
    if koPage:
        hdr['Accept-Langauge'] = 'ko'
        cookies = dict(language='ko')
    if referer:
        hdr['Referer'] = referer
    r = requests.get(page_url, headers=hdr, cookies=cookies)
    html = r.text
    vid_title = re.compile('<meta property="og:title" content="(.*?)"', re.S).search(html).group(1).strip()
    #vid_title = re.compile('<p class="episode_title".*?>(.*?)</div>', re.S).search(html).group(1).strip()
    match = re.compile("""(http[^'"]*m3u8)""").search(html, re.I|re.U)
    if not match:
        return None
    vid_url = match.group(1)
    videos = dict()
    if '_1080.m3u8' :
        videos[3792] = {'url':vid_url}
    elif '_720p.m3u8' in vid_url:
        for bitrate, resolution in bitrate2resolution.iteritems():
            videos[resolution] = {'url':vid_url.replace('720p', resolution)}
    return {'title':vid_title, 'videos':videos}

# mp4
def extractVideoUrl(page_url, koPage=True, referer=None):
    hdr = default_hdr
    hdr['User-Agent'] = tablet_UA
    cookies = None
    if koPage:
        hdr['Accept-Langauge'] = 'ko'
        cookies = dict(language='ko')
    if referer:
        hdr['Referer'] = referer
    r = requests.get(page_url, headers=hdr, cookies=cookies)
    html = r.text
    vid_title = re.compile('<meta property="og:title" content="(.*?)"', re.S).search(html).group(1).strip()
    match = re.compile("""(http[^'"]*mp4)""").search(html)
    if not match:
        return None
    vid_url = match.group(1)
    videos = dict()
    for bitrate, resolution in bitrate2resolution.iteritems():
        videos[resolution] = {'url':vid_url.replace('360p', resolution)}
    return {'title':vid_title, 'videos':videos}

if __name__ == "__main__":
    #print parseTop()
    #parseGenre( "variety", sort="popular" )
    #print(parseGenre( "variety" ))
    #print(parseEpisodePage( root_url+"/includes15/episode_page/infinite-challenge_63032_ko_1" ))
    #print(extractStreamUrl( root_url+"/infinite-challenge-e452.html" ))
    #print(extractVideoUrl( root_url+"/infinite-challenge-e452.html" ))
    #print(parseEpisodePage2( root_url+"/mystery-music-show-mask-king-e31.html" ))
    #print(extractVideoUrl( root_url+"/mystery-music-show-mask-king-e31.html" ))
    url = extractMovieDataUrlFromPage(root_url+"/pay-per-view")
    print(url)
    print(parseMoviePage(url, sort="popular"))
    print(extractStreamUrl( root_url+"/peninsula.html" ))

# vim:sw=4:sts=4:et
